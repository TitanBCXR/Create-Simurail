package com.crystaelix.simurail.content;

import com.crystaelix.simurail.Simurail;
import com.crystaelix.simurail.content.automatic_coupler.AutomaticCouplerBlockEntity;
import com.crystaelix.simurail.content.automatic_coupler.AutomaticCouplerRenderer;
import com.crystaelix.simurail.content.automatic_coupler.AutomaticCouplerVisual;
import com.crystaelix.simurail.content.automatic_coupler.copycat.CopycatAutomaticCouplerBlockEntity;
import com.crystaelix.simurail.content.automatic_coupler.copycat.CopycatAutomaticCouplerRenderer;
import com.crystaelix.simurail.content.automatic_coupler.copycat.CopycatAutomaticCouplerVisual;
import com.crystaelix.simurail.content.bogey.PhysicsBogeyBlockEntity;
import com.crystaelix.simurail.content.bogey.PhysicsBogeyPivotBlockEntity;
import com.crystaelix.simurail.content.bogey.PhysicsBogeyRenderer;
import com.crystaelix.simurail.content.bogey.PhysicsBogeyVisual;
import com.crystaelix.simurail.content.gangway_frame.GangwayFrameBlockEntity;
import com.crystaelix.simurail.content.gangway_frame.GangwayFrameRenderer;
import com.crystaelix.simurail.content.physics_roller.PhysicsRollerBlockEntity;
import com.crystaelix.simurail.content.physics_roller.PhysicsRollerRenderer;
import com.crystaelix.simurail.content.physics_roller.PhysicsRollerVisual;
import com.crystaelix.simurail.content.probe_reader.ProbeReaderBlockEntity;
import com.crystaelix.simurail.content.remote_controller.RemoteControllerBlockEntity;
import com.crystaelix.simurail.content.track_switch.TrackSwitchBlockEntity;
import com.crystaelix.simurail.content.track_switch.TrackSwitchRenderer;
import com.crystaelix.simurail.content.track_switch.TrackSwitchVisual;
import com.simibubi.create.foundation.data.CreateRegistrate;
import com.tterrag.registrate.util.entry.BlockEntityEntry;

import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;

public class SimurailBlockEntities {

	private static final CreateRegistrate REGISTRATE = Simurail.registrate();

	public static final BlockEntityEntry<PhysicsBogeyBlockEntity> PHYSICS_BOGEY = REGISTRATE.
			blockEntity("physics_bogey", PhysicsBogeyBlockEntity::new).
			visual(() -> PhysicsBogeyVisual::new, false).
			renderer(() -> PhysicsBogeyRenderer::new).
			validBlocks(SimurailBlocks.PHYSICS_BOGEY, SimurailBlocks.UNPOWERED_PHYSICS_BOGEY).
			register();
	public static final BlockEntityEntry<PhysicsBogeyPivotBlockEntity> PHYSICS_BOGEY_PIVOT = REGISTRATE.
			blockEntity("physics_bogey_pivot", PhysicsBogeyPivotBlockEntity::new).
			validBlocks(SimurailBlocks.PHYSICS_BOGEY_PIVOT).
			register();
	public static final BlockEntityEntry<AutomaticCouplerBlockEntity> COUPLER = REGISTRATE.
			blockEntity("coupler", AutomaticCouplerBlockEntity::new).
			visual(() -> AutomaticCouplerVisual::new).
			renderer(() -> AutomaticCouplerRenderer::new).
			validBlocks(SimurailBlocks.AUTOMATIC_COUPLER).
			register();
	public static final BlockEntityEntry<CopycatAutomaticCouplerBlockEntity> COPYCAT_COUPLER = REGISTRATE.
			blockEntity("copycat_coupler", CopycatAutomaticCouplerBlockEntity::new).
			visual(() -> CopycatAutomaticCouplerVisual::new).
			renderer(() -> CopycatAutomaticCouplerRenderer::new).
			validBlocks(SimurailBlocks.COPYCAT_PANEL_AUTOMATIC_COUPLER).
			register();
	public static final BlockEntityEntry<GangwayFrameBlockEntity> GANGWAY_FRAME = REGISTRATE.
			blockEntity("gangway_frame", GangwayFrameBlockEntity::new).
			renderer(() -> GangwayFrameRenderer::new).
			validBlocks(SimurailBlocks.GANGWAY_FRAME).
			register();
	public static final BlockEntityEntry<ProbeReaderBlockEntity> PROBE_READER = REGISTRATE.
			blockEntity("probe_reader", ProbeReaderBlockEntity::new).
			validBlocks(SimurailBlocks.PROBE_READER).
			register();
	public static final BlockEntityEntry<RemoteControllerBlockEntity> REMOTE_CONTROLLER = REGISTRATE.
			blockEntity("remote_controller", RemoteControllerBlockEntity::new).
			validBlocks(SimurailBlocks.REMOTE_CONTROLLER).
			register();
	public static final BlockEntityEntry<TrackSwitchBlockEntity> TRACK_SWITCH = REGISTRATE.
			blockEntity("track_switch", TrackSwitchBlockEntity::new).
			visual(() -> TrackSwitchVisual::new).
			renderer(() -> TrackSwitchRenderer::new).
			validBlocks(SimurailBlocks.TRACK_SWITCH).
			register();
	public static final BlockEntityEntry<PhysicsRollerBlockEntity> PHYSICS_ROLLER = REGISTRATE.
			blockEntity("physics_roller", PhysicsRollerBlockEntity::new).
			visual(() -> PhysicsRollerVisual::new).
			renderer(() -> PhysicsRollerRenderer::new).
			validBlocks(SimurailBlocks.PHYSICS_ROLLER).
			register();

	public static void register() {
	}

	public static void registerCapabilities(RegisterCapabilitiesEvent event) {
		PhysicsBogeyBlockEntity.registerCapabilities(event);
		ProbeReaderBlockEntity.registerCapabilities(event);
		RemoteControllerBlockEntity.registerCapabilities(event);
		TrackSwitchBlockEntity.registerCapabilities(event);
	}
}
