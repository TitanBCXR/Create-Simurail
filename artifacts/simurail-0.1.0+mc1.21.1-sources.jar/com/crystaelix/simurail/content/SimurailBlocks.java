package com.crystaelix.simurail.content;

import com.crystaelix.simurail.Simurail;
import com.crystaelix.simurail.content.automatic_coupler.AutomaticCouplerBlock;
import com.crystaelix.simurail.content.automatic_coupler.AutomaticCouplerBlockItem;
import com.crystaelix.simurail.content.automatic_coupler.copycat.CopycatAutomaticCouplerBlockItem;
import com.crystaelix.simurail.content.automatic_coupler.copycat.CopycatBarsAutomaticCouplerBlock;
import com.crystaelix.simurail.content.automatic_coupler.copycat.CopycatBarsAutomaticCouplerModel;
import com.crystaelix.simurail.content.automatic_coupler.copycat.CopycatPanelAutomaticCouplerBlock;
import com.crystaelix.simurail.content.automatic_coupler.copycat.CopycatPanelAutomaticCouplerModel;
import com.crystaelix.simurail.content.bogey.PhysicsBogeyBlock;
import com.crystaelix.simurail.content.bogey.PhysicsBogeyBlockItem;
import com.crystaelix.simurail.content.bogey.PhysicsBogeyPivotBlock;
import com.crystaelix.simurail.content.bogey.UnpoweredPhysicsBogeyBlock;
import com.crystaelix.simurail.content.bogey.UnpoweredPhysicsBogeyBlockItem;
import com.crystaelix.simurail.content.gangway_frame.GangwayFrameBlock;
import com.crystaelix.simurail.content.physics_roller.PhysicsRollerBlock;
import com.crystaelix.simurail.content.physics_roller.PhysicsRollerBlockItem;
import com.crystaelix.simurail.content.probe_reader.ProbeReaderBlock;
import com.crystaelix.simurail.content.probe_reader.ProbeReaderBlockItem;
import com.crystaelix.simurail.content.remote_controller.RemoteControllerBlock;
import com.crystaelix.simurail.content.remote_controller.RemoteControllerBlockItem;
import com.crystaelix.simurail.content.track_switch.TrackSwitchBlock;
import com.crystaelix.simurail.content.track_switch.TrackSwitchBlockItem;
import com.simibubi.create.api.behaviour.display.DisplaySource;
import com.simibubi.create.foundation.data.BuilderTransformers;
import com.simibubi.create.foundation.data.CreateRegistrate;
import com.simibubi.create.foundation.data.SharedProperties;
import com.tterrag.registrate.util.entry.BlockEntry;

import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.material.MapColor;

public class SimurailBlocks {

	private static final CreateRegistrate REGISTRATE = Simurail.registrate();

	public static final BlockEntry<PhysicsBogeyBlock> PHYSICS_BOGEY = REGISTRATE.
			block("physics_bogey", PhysicsBogeyBlock::new).
			initialProperties(SharedProperties::softMetal).
			properties(p -> p.noOcclusion().mapColor(MapColor.TERRACOTTA_CYAN).sound(SoundType.NETHERITE_BLOCK)).
			item(PhysicsBogeyBlockItem::new).
			build().
			register();
	public static final BlockEntry<UnpoweredPhysicsBogeyBlock> UNPOWERED_PHYSICS_BOGEY = REGISTRATE.
			block("unpowered_physics_bogey", UnpoweredPhysicsBogeyBlock::new).
			initialProperties(SharedProperties::softMetal).
			properties(p -> p.noOcclusion().mapColor(MapColor.TERRACOTTA_CYAN).sound(SoundType.NETHERITE_BLOCK)).
			item(UnpoweredPhysicsBogeyBlockItem::new).
			build().
			register();
	public static final BlockEntry<PhysicsBogeyPivotBlock> PHYSICS_BOGEY_PIVOT = REGISTRATE.
			block("physics_bogey_pivot", PhysicsBogeyPivotBlock::new).
			properties(p -> p.noOcclusion().noTerrainParticles().noLootTable()).
			register();
	public static final BlockEntry<AutomaticCouplerBlock> AUTOMATIC_COUPLER = REGISTRATE.
			block("automatic_coupler", AutomaticCouplerBlock::new).
			initialProperties(SharedProperties::softMetal).
			properties(p -> p.noOcclusion().dynamicShape().mapColor(MapColor.NONE).sound(SoundType.METAL)).
			item(AutomaticCouplerBlockItem::new).
			build().
			register();
	public static final BlockEntry<CopycatPanelAutomaticCouplerBlock> COPYCAT_PANEL_AUTOMATIC_COUPLER = REGISTRATE.
			block("copycat_panel_automatic_coupler", CopycatPanelAutomaticCouplerBlock::new).
			transform(BuilderTransformers.copycat()).
			properties(p -> p.dynamicShape()).
			onRegister(CreateRegistrate.blockModel(() -> CopycatPanelAutomaticCouplerModel::new)).
			item(CopycatAutomaticCouplerBlockItem::new).
			build().
			register();
	public static final BlockEntry<CopycatBarsAutomaticCouplerBlock> COPYCAT_BARS_AUTOMATIC_COUPLER = REGISTRATE.
			block("copycat_bars_automatic_coupler", CopycatBarsAutomaticCouplerBlock::new).
			onRegister(CreateRegistrate.blockModel(() -> CopycatBarsAutomaticCouplerModel::new)).
			register();
	public static final BlockEntry<GangwayFrameBlock> GANGWAY_FRAME = REGISTRATE.
			block("gangway_frame", GangwayFrameBlock::new).
			initialProperties(SharedProperties::softMetal).
			properties(p -> p.noOcclusion().dynamicShape().mapColor(MapColor.NONE).sound(SoundType.METAL)).
			simpleItem().
			register();
	public static final BlockEntry<ProbeReaderBlock> PROBE_READER = REGISTRATE.
			block("probe_reader", ProbeReaderBlock::new).
			initialProperties(SharedProperties::softMetal).
			properties(p -> p.noOcclusion().mapColor(MapColor.NONE).sound(SoundType.METAL)).
			item(ProbeReaderBlockItem::new).
			build().
			register();
	public static final BlockEntry<RemoteControllerBlock> REMOTE_CONTROLLER = REGISTRATE.
			block("remote_controller", RemoteControllerBlock::new).
			initialProperties(SharedProperties::softMetal).
			properties(p -> p.noOcclusion().mapColor(MapColor.NONE).sound(SoundType.METAL)).
			item(RemoteControllerBlockItem::new).
			build().
			register();
	public static final BlockEntry<TrackSwitchBlock> TRACK_SWITCH = REGISTRATE.
			block("track_switch", TrackSwitchBlock::new).
			initialProperties(SharedProperties::softMetal).
			properties(p -> p.noOcclusion().mapColor(MapColor.TERRACOTTA_CYAN).sound(SoundType.NETHERITE_BLOCK)).
			transform(DisplaySource.displaySource(SimurailDisplaySources.TRACK_SWITCH)).
			item(TrackSwitchBlockItem::new).
			build().
			register();
	public static final BlockEntry<PhysicsRollerBlock> PHYSICS_ROLLER = REGISTRATE.
			block("physics_roller", PhysicsRollerBlock::new).
			initialProperties(SharedProperties::softMetal).
			properties(p -> p.noOcclusion().mapColor(MapColor.TERRACOTTA_YELLOW).sound(SoundType.METAL)).
			item(PhysicsRollerBlockItem::new).
			build().
			register();

	public static void register() {
	}
}
