package com.crystaelix.simurail.content.bogey;

import com.crystaelix.simurail.api.bogey.BogeySubtype;

import io.netty.buffer.ByteBuf;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.codec.StreamCodec;

public class PhysicsBogeyOptions {

	public static final StreamCodec<ByteBuf, PhysicsBogeyOptions> STREAM_CODEC = StreamCodec.of(
			(b, v) -> v.encode(b), b -> new PhysicsBogeyOptions().decode(b));

	public BogeySubtype type = BogeySubtype.getFallback();
	public boolean enabled = true;
	public boolean allowYawOffset = true;
	public boolean allowPitchOffset = true;
	public boolean allowVerticalOffset = false;
	public boolean allowLateralOffset = false;
	public boolean allowVerticalMovement = false;
	public boolean renderFrontConnector = true;
	public boolean renderBackConnector = true;
	public boolean forceLoad = false;
	public PhysicsBogeyControlMode controlMode = PhysicsBogeyControlMode.BRAKING;

	private float axleOffset = 0;
	private float stress = 8;
	private float tiltStrength = 0;
	private float probeDistance = 0;

	public PhysicsBogeyOptions() {}

	public PhysicsBogeyOptions(boolean unpowered, boolean inverted) {
		if(unpowered) {
			stress = 0;
		}
		type = BogeySubtype.getFallback(inverted);
	}

	public PhysicsBogeyOptions set(PhysicsBogeyOptions other) {
		type = other.type;
		enabled = other.enabled;
		allowYawOffset = other.allowYawOffset;
		allowPitchOffset = other.allowPitchOffset;
		allowVerticalOffset = other.allowVerticalOffset;
		allowLateralOffset = other.allowLateralOffset;
		allowVerticalMovement = other.allowVerticalMovement;
		renderFrontConnector = other.renderFrontConnector;
		renderBackConnector = other.renderBackConnector;
		forceLoad = other.forceLoad;
		controlMode = other.controlMode;
		axleOffset = other.axleOffset;
		stress = other.stress;
		tiltStrength = other.tiltStrength;
		probeDistance = other.probeDistance;
		return this;
	}

	public PhysicsBogeyOptions setNonComputer(PhysicsBogeyOptions other) {
		type = other.type;
		renderFrontConnector = other.renderFrontConnector;
		renderBackConnector = other.renderBackConnector;
		return this;
	}

	public float getAxleOffset() {
		return axleOffset;
	}

	public PhysicsBogeyOptions setAxleOffset(float axleOffset) {
		this.axleOffset = Math.clamp(axleOffset, -1, 1);
		return this;
	}

	public float getStress() {
		return stress;
	}

	public PhysicsBogeyOptions setStress(float stress) {
		this.stress = Math.clamp(stress, -128, 128);
		return this;
	}

	public float getTiltStrength() {
		return tiltStrength;
	}

	public PhysicsBogeyOptions setTiltStrength(float tiltStrength) {
		this.tiltStrength = Math.clamp(tiltStrength, 0, 1);
		return this;
	}

	public float getProbeDistance() {
		return probeDistance;
	}

	public PhysicsBogeyOptions setProbeDistance(float probeDistance) {
		this.probeDistance = Math.clamp(probeDistance, 0, 256);
		return this;
	}

	public int getAngularType() {
		return allowYawOffset ? allowPitchOffset ? 1 : 2 : allowPitchOffset ? 3 : 0;
	}

	public PhysicsBogeyOptions setAngularType(int typeIndex) {
		switch(typeIndex) {
		case 0 -> {
			allowYawOffset = false;
			allowPitchOffset = false;
		}
		case 1 -> {
			allowYawOffset = true;
			allowPitchOffset = true;
		}
		case 2 -> {
			allowYawOffset = true;
			allowPitchOffset = false;
		}
		case 3 -> {
			allowYawOffset = false;
			allowPitchOffset = true;
		}
		}
		return this;
	}

	public int getLinearType() {
		return allowVerticalOffset ? allowLateralOffset ? 1 : 3 : allowLateralOffset ? 2 : 0;
	}

	public PhysicsBogeyOptions setLinearType(int typeIndex) {
		switch(typeIndex) {
		case 0 -> {
			allowVerticalOffset = false;
			allowLateralOffset = false;
		}
		case 1 -> {
			allowVerticalOffset = true;
			allowLateralOffset = true;
		}
		case 2 -> {
			allowVerticalOffset = false;
			allowLateralOffset = true;
		}
		case 3 -> {
			allowVerticalOffset = true;
			allowLateralOffset = false;
		}
		}
		return this;
	}
	
	public int getOffsetPreset() {
		int angularType = getAngularType();
		int linearType = getLinearType();
		if(angularType == 0 && linearType == 0) {
			return 1;
		}
		if(angularType == 1 && linearType == 0) {
			return 2;
		}
		if(angularType == 1 && linearType == 1) {
			return 3;
		}
		return 0;
	}

	public PhysicsBogeyOptions setOffsetPreset(int presetIndex) {
		switch(presetIndex) {
		case 1 -> {
			setAngularType(0);
			setLinearType(0);
		}
		case 2 -> {
			setAngularType(1);
			setLinearType(0);
		}
		case 3 -> {
			setAngularType(1);
			setLinearType(1);
		}
		}
		return this;
	}

	public int getConnectorType() {
		return renderFrontConnector ? renderBackConnector ? 0 : 2 : allowLateralOffset ? 3 : 1;
	}

	public PhysicsBogeyOptions setConnectorType(int typeIndex) {
		switch(typeIndex) {
		case 0 -> {
			renderFrontConnector = true;
			renderBackConnector = true;
		}
		case 1 -> {
			renderFrontConnector = false;
			renderBackConnector = false;
		}
		case 2 -> {
			renderFrontConnector = true;
			renderBackConnector = false;
		}
		case 3 -> {
			renderFrontConnector = false;
			renderBackConnector = true;
		}
		}
		return this;
	}

	public short getFlags() {
		short flags = 0;
		if(enabled)               flags |= 1;
		if(allowYawOffset)        flags |= 2;
		if(allowPitchOffset)      flags |= 4;
		if(allowVerticalOffset)   flags |= 8;
		if(allowLateralOffset)    flags |= 16;
		if(allowVerticalMovement) flags |= 32;
		if(renderFrontConnector)  flags |= 64;
		if(renderBackConnector)   flags |= 128;
		if(forceLoad)             flags |= 256;
		return flags;
	}

	public PhysicsBogeyOptions setFlags(short flags) {
		enabled               = (flags & 1)   != 0;
		allowYawOffset        = (flags & 2)   != 0;
		allowPitchOffset      = (flags & 4)   != 0;
		allowVerticalOffset   = (flags & 8)   != 0;
		allowLateralOffset    = (flags & 16)  != 0;
		allowVerticalMovement = (flags & 32)  != 0;
		renderFrontConnector  = (flags & 64)  != 0;
		renderBackConnector   = (flags & 128) != 0;
		forceLoad             = (flags & 256) != 0;
		return this;
	}

	public CompoundTag write() {
		CompoundTag tag = new CompoundTag();
		tag.put("type", type.write());
		tag.putShort("flags", getFlags());
		tag.putByte("control_mode", (byte)controlMode.ordinal());
		tag.putFloat("axle_offset", axleOffset);
		tag.putFloat("stress", stress);
		tag.putFloat("tilt_strength", tiltStrength);
		tag.putFloat("probe_distance", probeDistance);
		return tag;
	}

	public PhysicsBogeyOptions read(CompoundTag tag) {
		type = BogeySubtype.read(tag.getCompound("type"));
		setFlags(tag.getShort("flags"));
		controlMode = PhysicsBogeyControlMode.BY_ID.apply(tag.getByte("control_mode"));
		axleOffset = Math.clamp(tag.getFloat("axle_offset"), -1, 1);
		stress = Math.clamp(tag.getFloat("stress"), -128, 128);
		tiltStrength = Math.clamp(tag.getFloat("tilt_strength"), 0, 1);
		probeDistance = Math.clamp(tag.getFloat("probe_distance"), 0, 256);
		return this;
	}

	public void encode(ByteBuf buf) {
		BogeySubtype.STREAM_CODEC.encode(buf, type);
		buf.writeShort(getFlags());
		PhysicsBogeyControlMode.STREAM_CODEC.encode(buf, controlMode);
		buf.writeFloat(axleOffset);
		buf.writeFloat(stress);
		buf.writeFloat(tiltStrength);
		buf.writeFloat(probeDistance);
	}

	public PhysicsBogeyOptions decode(ByteBuf buf) {
		type = BogeySubtype.STREAM_CODEC.decode(buf);
		setFlags(buf.readShort());
		controlMode = PhysicsBogeyControlMode.STREAM_CODEC.decode(buf);
		axleOffset = buf.readFloat();
		stress = buf.readFloat();
		tiltStrength = buf.readFloat();
		probeDistance = buf.readFloat();
		return this;
	}
}
