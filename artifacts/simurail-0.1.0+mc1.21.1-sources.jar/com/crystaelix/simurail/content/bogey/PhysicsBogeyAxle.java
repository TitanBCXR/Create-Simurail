package com.crystaelix.simurail.content.bogey;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import org.apache.commons.lang3.mutable.MutableBoolean;
import org.joml.Quaterniond;
import org.joml.Quaterniondc;
import org.joml.Vector3d;
import org.joml.Vector3dc;

import com.crystaelix.simurail.api.extension.BezierConnectionExtension;
import com.crystaelix.simurail.api.math.Frame3d;
import com.crystaelix.simurail.api.math.Frame3dc;
import com.crystaelix.simurail.api.math.SimurailMath;
import com.crystaelix.simurail.api.physics.AttachableBoxPhysicsObject;
import com.crystaelix.simurail.api.physics.SimurailJoints;
import com.crystaelix.simurail.api.signal.SignalNameRegistry;
import com.crystaelix.simurail.api.track.TrackTypeEntries;
import com.crystaelix.simurail.api.track.TrackTypeEntry;
import com.crystaelix.simurail.config.SimurailConfig;
import com.crystaelix.simurail.config.SimurailPhysicsConfig;
import com.crystaelix.simurail.content.SimurailForceGroups;
import com.crystaelix.simurail.content.track.CurvedTrackSegment;
import com.crystaelix.simurail.content.track.TrackSegment;
import com.crystaelix.simurail.content.track.TrackSegmentHelper;
import com.crystaelix.simurail.extension.SignalEdgeGroupExtension;
import com.crystaelix.simurail.extension.TrackObserverExtension;
import com.machinezoo.noexception.CloseableScope;
import com.simibubi.create.Create;
import com.simibubi.create.content.trains.entity.TravellingPoint;
import com.simibubi.create.content.trains.entity.TravellingPoint.ITrackSelector;
import com.simibubi.create.content.trains.graph.TrackEdge;
import com.simibubi.create.content.trains.graph.TrackGraph;
import com.simibubi.create.content.trains.graph.TrackNode;
import com.simibubi.create.content.trains.signal.SignalBoundary;
import com.simibubi.create.content.trains.signal.SignalEdgeGroup;
import com.simibubi.create.content.trains.signal.TrackEdgePoint;
import com.simibubi.create.content.trains.station.GlobalStation;
import com.simibubi.create.content.trains.track.BezierConnection;

import dev.ryanhcode.sable.Sable;
import dev.ryanhcode.sable.api.physics.constraint.ConstraintJointAxis;
import dev.ryanhcode.sable.api.physics.constraint.FixedConstraintConfiguration;
import dev.ryanhcode.sable.api.physics.constraint.FixedConstraintHandle;
import dev.ryanhcode.sable.api.physics.constraint.GenericConstraintConfiguration;
import dev.ryanhcode.sable.api.physics.constraint.GenericConstraintHandle;
import dev.ryanhcode.sable.api.physics.force.QueuedForceGroup;
import dev.ryanhcode.sable.api.physics.handle.RigidBodyHandle;
import dev.ryanhcode.sable.api.physics.mass.MassData;
import dev.ryanhcode.sable.companion.math.JOMLConversion;
import dev.ryanhcode.sable.companion.math.Pose3d;
import dev.ryanhcode.sable.companion.math.Pose3dc;
import dev.ryanhcode.sable.mixinterface.clip_overwrite.ClipContextExtension;
import dev.ryanhcode.sable.physics.config.block_properties.PhysicsBlockPropertyHelper;
import dev.ryanhcode.sable.sublevel.ServerSubLevel;
import dev.ryanhcode.sable.sublevel.system.SubLevelPhysicsSystem;
import it.unimi.dsi.fastutil.booleans.BooleanConsumer;
import it.unimi.dsi.fastutil.objects.Object2DoubleArrayMap;
import it.unimi.dsi.fastutil.objects.Object2DoubleMap;
import net.createmod.catnip.data.Couple;
import net.createmod.catnip.data.Pair;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.CollisionContext;

public class PhysicsBogeyAxle {

	public static final double ANGULAR_Y_LIMIT = Math.PI / 3;
	public static final double ANGULAR_Z_LIMIT = Math.PI / 3;

	public static final double MAX_SLIP_OVERLOAD = 2;
	public static final double SLIP_GRIP_SPEED = 0.25;
	public static final double SLIP_RELEASE_TIME = 0.1;
	public static final double SLIP_FADE_BAND = 0.5;

	protected final PhysicsBogeyBlockEntity bogey;
	protected final boolean logicalFront;
	protected final Frame3d axleFrame = new Frame3d();

	protected final Vector3d lastOffset = new Vector3d();
	protected final Vector3d targetOffset = new Vector3d();
	protected final Vector3d currentOffset = new Vector3d();
	protected final Vector3d staticAxleBogeyPos = new Vector3d();
	protected float vertOffset;
	protected double offsetTimer = 0;

	protected TrackSegment trackSegment;
	protected ServerSubLevel trackSubLevel;
	protected Pose3dc trackSubLevelPose;

	protected TrackGraph trackGraph;
	protected TravellingPoint trackPoint = new TravellingPoint();
	protected TravellingPoint probe = new TravellingPoint();

	protected List<Couple<TrackNode>> currentPath = new ArrayList<>();

	protected BlockHitResult clipResult;
	protected ServerSubLevel clipSubLevel;

	protected GenericConstraintHandle trackJoint;
	protected GenericConstraintHandle bogeyJoint;
	protected boolean yFixed = false;
	protected boolean zFixed = false;
	protected double yFixedTimer = 0;
	protected double zFixedTimer = 0;

	protected double speed;
	protected double targetSpeed;
	protected double visualSpeedLerpFactor;
	protected double visualSpeed;

	protected double slipSpeed;
	protected double slipBind;
	protected double slipBurst;

	protected double trackRecheckTime = 0.5;

	protected AttachableBoxPhysicsObject axleBox;
	protected FixedConstraintHandle axleBoxJoint;

	protected double kLateralSigned;
	protected double kLateral;
	protected double kVertical;

	protected PhysicsBogeyProbeData probeData = new PhysicsBogeyProbeData();

	public PhysicsBogeyAxle(PhysicsBogeyBlockEntity bogey, boolean logicalFront) {
		this.bogey = bogey;
		this.logicalFront = logicalFront;
	}

	protected void init(ServerSubLevel subLevel) {
		double latOffset = bogey.options.type.logicalAxleSpacing() * 0.5;
		vertOffset = bogey.options.getAxleOffset();
		targetOffset.x = logicalFront ? latOffset : -latOffset;
		targetOffset.y = bogey.isInverted() ? 0.5 + vertOffset : -1.5 - vertOffset;
		if(offsetTimer > 0) {
			targetOffset.lerp(lastOffset, offsetTimer, currentOffset);
		}
		else {
			currentOffset.set(targetOffset);
		}
		axleFrame.position.set(currentOffset);
		staticAxleBogeyPos.set(currentOffset).rotate(bogey.getJointOrientation()).add(bogey.localCenter);
		if(trackSegment == null) {
			trackRecheckTime = 0.05;
		}
		updateTrack(subLevel, 0);
	}

	protected void resetOffset() {
		lastOffset.set(currentOffset);
		double latOffset = bogey.options.type.logicalAxleSpacing() * 0.5;
		vertOffset = bogey.options.getAxleOffset();
		targetOffset.x = logicalFront ? latOffset : -latOffset;
		targetOffset.y = bogey.isInverted() ? 0.5 + vertOffset : -1.5 - vertOffset;
		offsetTimer = 1;
		trackRecheckTime = 0.05;
	}

	protected void updateVisualSpeed() {
		double decay = 0.95 * (1 - bogey.getGroupBrakeStrength());
		visualSpeed = visualSpeed * decay;
		slipSpeed = slipSpeed * decay;
		slipBurst = slipBurst * decay;
	}

	protected void resetSlip() {
		slipSpeed = 0;
		slipBind = 0;
		slipBurst = 0;
	}

	protected void updateSignalGroup() {
		if(trackGraph != null && trackPoint.edge != null) {
			UUID signalGroupId = trackPoint.edge.getEdgeData().getGroupAtPosition(trackGraph, trackPoint.position);
			if(signalGroupId != null) {
				SignalEdgeGroup signalGroup = Create.RAILWAYS.signalEdgeGroups.get(signalGroupId);
				if(signalGroup != null) {
					((SignalEdgeGroupExtension)signalGroup).simurail$queueBogey(bogey);
				}
			}
		}
	}

	protected void updateInnerProbe() {
		if(trackGraph != null && trackPoint.edge != null) {
			resetProbe(trackPoint);
			double travelDist = bogey.options.type.logicalAxleSpacing() * 0.5;
			if(logicalFront) travelDist *= -1;
			probe.travel(trackGraph,
					travelDist,
					followOtherOrSteer(probe),
					(distance, couple) -> {
						if(couple.getFirst() instanceof TrackObserverExtension observer) {
							observer.simurail$keepAlive(bogey);
						}
						return false;
					},
					probe.ignoreTurns(),
					$ -> true);
		}
	}

	protected void updateOuterProbe() {
		try(CloseableScope scope = probeData.writeScope()) {
			probeData.reset();
			double travelDist = bogey.options.getProbeDistance();
			if(travelDist > 0 && trackGraph != null && trackPoint.edge != null) {
				resetProbe(trackPoint);
				//double resetDist = bogey.options.type.logicalAxleSpacing() * 0.5 - 0.0625;
				//if(logicalFront) resetDist *= -1;
				//probe.travel(trackGraph, resetDist, followOtherOrSteer(probe), probe.ignoreEdgePoints(), probe.ignoreTurns(), $ -> true);
				if(!logicalFront) travelDist *= -1;
				double traveled = probe.travel(
						trackGraph,
						travelDist,
						(isCurrentFront() ? control(probe) : steer(probe)),
						(distance, couple) -> {
							TrackEdgePoint point = couple.getFirst();
							Couple<TrackNode> nodes = couple.getSecond();
							TrackEdge edge = trackGraph.getConnection(nodes);
							switch(point) {
							case GlobalStation station -> {
								if(probeData.stationDistance < 0) {
									probeData.stationDistance = Math.abs(distance);
									probeData.stationName = station.name;
									probeData.stationId = station.id;
									probeData.stationPos = edge.getPosition(trackGraph, station.getLocationOn(edge) / edge.getLength());
									probeData.stationBlockPos = station.blockEntityPos;
									probeData.stationPowered = bogey.getLevel().hasNeighborSignal(station.blockEntityPos);
								}
							}
							case SignalBoundary signal -> {
								if(probeData.signalDistance < 0) {
									probeData.signalDistance = Math.abs(distance);
									probeData.signalNames = getSignalNames(signal, nodes.getSecond());
									probeData.signalPos = edge.getPosition(trackGraph, signal.getLocationOn(edge) / edge.getLength());
									probeData.signalAligned = signal.canNavigateVia(nodes.getSecond());
									probeData.signalBidirectional = signal.blockEntities.both(ps -> !ps.isEmpty());
								}
								if(probeData.occupiedSignalDistance < 0) {
									UUID signalEdgeGroupId = signal.getGroup(nodes.getSecond());
									SignalEdgeGroup signalEdgeGroup = Create.RAILWAYS.signalEdgeGroups.get(signalEdgeGroupId);
									SignalEdgeGroupExtension signalEdgeGroupE = (SignalEdgeGroupExtension)signalEdgeGroup;
									if(signalEdgeGroup != null && (signal.isForcedRed(nodes.getSecond()) || signalEdgeGroupE.simurail$isOccupiedUnless(bogey.group))) {
										probeData.occupiedSignalDistance = Math.abs(distance);
										probeData.occupiedSignalNames = getSignalNames(signal, nodes.getSecond());
										probeData.occupiedSignalPos = edge.getPosition(trackGraph, signal.getLocationOn(edge) / edge.getLength());
										probeData.occupiedSignalAligned = signal.canNavigateVia(nodes.getSecond());
										probeData.occupiedSignalBidirectional = signal.blockEntities.both(ps -> !ps.isEmpty());
										probeData.occupiedSignalForced = signal.isForcedRed(nodes.getSecond());
									}
								}
							}
							case null -> {}
							default -> {
								switch(point.getType().getId().toString()) {
								case "railways:buffer" -> {
									return true;
								}
								}
							}
							}
							return false;
						},
						probe.ignoreTurns(), $ -> true);
				if(probe.blocked) {
					probeData.discontinuityDistance = Math.abs(traveled);
				}
			}
		}
	}

	protected List<String> getSignalNames(SignalBoundary signal, TrackNode side) {
		Set<BlockPos> signalBlocks = signal.blockEntities.get(signal.isPrimary(side)).keySet();
		Level level = bogey.getLevel();
		return signalBlocks.stream().
				flatMap(pos -> Direction.stream().flatMap(dir -> {
					BlockPos relative = pos.relative(dir);
					BlockState state = level.getBlockState(relative);
					return SignalNameRegistry.getExtractors().stream().flatMap(e -> e.getSignalNames(state, level, relative, dir));
				})).
				filter(s -> !s.isBlank()).
				toList();
	}

	protected void updateOffsetChange() {
		if(vertOffset != bogey.options.getAxleOffset()) {
			resetOffset();
		}
	}

	protected void updateOffset(ServerSubLevel subLevel, double timeStep) {
		if(offsetTimer > 0) {
			offsetTimer -= timeStep / SimurailConfig.server().physics.axleSpacingUpdateTime.get();
			if(offsetTimer > 0) {
				targetOffset.lerp(lastOffset, offsetTimer, currentOffset);
			}
			else {
				currentOffset.set(targetOffset);
			}
			axleFrame.position.set(currentOffset);
			staticAxleBogeyPos.set(currentOffset).rotate(bogey.getJointOrientation()).add(bogey.localCenter);
		}
	}

	protected void updateTrack(ServerSubLevel subLevel, double timeStep) {
		trackRecheckTime -= timeStep;

		ServerLevel level = subLevel.getLevel();
		axleFrame.transform(bogey.pivotPose, globalAxleFrame);
		globalAxleFrame.transformInverse(subLevel.logicalPose(), bogeyAxleFrame);

		t:if(trackSegment != null) {
			trackSubLevel = (ServerSubLevel)Sable.HELPER.getContaining(level, trackSegment.start());
			trackSubLevelPose = trackSubLevel == null ? SimurailMath.POSE_I : trackSubLevel.logicalPose();
			globalAxleFrame.transformInverse(trackSubLevelPose, trackAxleFrame);

			boolean inverted = bogey.isInverted();
			if(!trackSegment.inSegmentRange(trackAxleFrame.position, trackAxleFrame.vertical, inverted)) {
				// No longer on track segment
				double t = trackSegment.projectT(trackAxleFrame.position);
				boolean reverse = t < 0.5;
				if(trackSegment instanceof CurvedTrackSegment curve) {
					CurvedTrackSegment nextSegment = curve.next(reverse);
					while(nextSegment != null) {
						if(!nextSegment.inLineRange(trackAxleFrame.position, trackAxleFrame.vertical, inverted)) {
							break;
						}
						if(nextSegment.inProjectionRange(trackAxleFrame.position, trackAxleFrame.vertical)) {
							trackSegment = nextSegment;
							trackRecheckTime = SimurailConfig.server().physics.axleTrackRecheckTime.get();
							bogey.setChanged();
							break t;
						}
						else {
							nextSegment = nextSegment.next(reverse);
						}
					}
				}

				updateGraph(false);
				if(trackGraph != null) {
					resetProbe(trackPoint);
					probe.position = reverse ? 0.05 : probe.edge.getLength() - 0.05;
					probe.travel(trackGraph, reverse ? -0.1 : 0.1,
							control(probe),
							probe.ignoreEdgePoints(),
							probe.ignoreTurns(),
							$ -> true);
					if(!probe.blocked) {
						TrackSegment nextSegment = TrackSegmentHelper.fromTrackEdge(probe.edge, reverse);
						while(nextSegment != null) {
							if(!nextSegment.inLineRange(trackAxleFrame.position, trackAxleFrame.vertical, inverted)) {
								break;
							}
							if(nextSegment.inProjectionRange(trackAxleFrame.position, trackAxleFrame.vertical)) {
								trackSegment = nextSegment;
								trackRecheckTime = SimurailConfig.server().physics.axleTrackRecheckTime.get();
								bogey.setChanged();
								break t;
							}
							else if(nextSegment instanceof CurvedTrackSegment curve) {
								nextSegment = curve.next(reverse);
							}
							else {
								break;
							}
						}
					}
				}

				findTrack(subLevel);
			}
		}

		if(trackRecheckTime <= 0) {
			findTrack(subLevel);
		}

		if(!bogey.options.enabled) {
			yFixed = zFixed = false;
			yFixedTimer = zFixedTimer = 0;
		}

		speed = 0;
		RigidBodyHandle.of(subLevel.getLevel(), bogey.pivot.physicsBody()).getLinearVelocity(globalAxleVel);

		if(trackSegment != null) {
			ServerSubLevel newTrackSubLevel = (ServerSubLevel)Sable.HELPER.getContaining(level, trackSegment.start());
			if(trackSubLevel != newTrackSubLevel) {
				removeJoint();
				trackSubLevel = newTrackSubLevel;
			}
			trackSubLevelPose = trackSubLevel == null ? SimurailMath.POSE_I : trackSubLevel.logicalPose();
			globalAxleFrame.transformInverse(trackSubLevelPose, trackAxleFrame);

			double t = trackSegment.projectT(trackAxleFrame.position);
			trackSegment.frame(t, trackFrame);
			if(trackAxleFrame.direction.dot(trackFrame.direction) < 0) {
				trackSegment = trackSegment.reverse();
				trackFrame.direction.negate();
				trackFrame.lateral.negate();
			}
			trackFrame.orientation(globalTrackRot).premul(trackSubLevelPose.orientation());

			bogeyForceFrame.set(trackFrame);
			bogeyForceFrame.position.fma(0.5, trackFrame.vertical);
			bogeyForceFrame.transform(trackSubLevelPose).transformInverse(subLevel.logicalPose());

			Sable.HELPER.getVelocity(subLevel.getLevel(), trackAxleFrame.position, globalTrackVel);
			globalAxleVel.sub(globalTrackVel, globalRelVel);
			subLevel.logicalPose().transformNormalInverse(globalRelVel, bogeyRelVel);
			speed = bogeyRelVel.dot(bogeyForceFrame.direction);
		}
		else {
			yFixed = zFixed = false;
			yFixedTimer = zFixedTimer = 0;
			removeJoint();
			globalAxleFrame.orientation(globalTrackRot);

			clipResult = findGround(subLevel);
			if(clipResult.getType() == HitResult.Type.BLOCK) {
				JOMLConversion.toJOML(clipResult.getLocation(), clipPos);
				clipSubLevel = (ServerSubLevel)Sable.HELPER.getContaining(level, clipPos);

				bogeyForceFrame.set(axleFrame);
				bogeyForceFrame.position.fma(0.5, axleFrame.vertical);
				bogeyForceFrame.transform(bogey.pivotPose).transformInverse(subLevel.logicalPose());

				Sable.HELPER.getVelocity(level, clipPos, globalHitVel);
				globalAxleVel.sub(globalHitVel, globalRelVel);
				subLevel.logicalPose().transformNormalInverse(globalRelVel, bogeyRelVel);
				speed = bogeyRelVel.dot(bogeyForceFrame.direction);
			}
		}
		if(Math.abs(speed) < 1E-3) {
			speed = 0;
		}
		updateGraph(true);
	}

	protected void updateGraph(boolean updatePosition) {
		TrackEdge trackEdge = null;

		if(trackSegment == null) {
			trackGraph = null;
		}
		else {
			if(trackGraph != null) {
				trackEdge = trackSegment.graphEdge(trackGraph);
				if(trackEdge == null) {
					// Graph changed
					trackGraph = null;
				}
			}
			if(trackGraph == null) {
				Pair<TrackGraph, TrackEdge> connection = trackSegment.graphConnection();
				if(connection != null) {
					trackGraph = connection.getFirst();
					trackEdge = connection.getSecond();
				}
			}
		}

		if(trackEdge == null) {
			trackPoint.node1 = null;
			trackPoint.node2 = null;
			trackPoint.edge = null;
			trackPoint.position = 0;
		}
		else {
			trackPoint.node1 = trackEdge.node1;
			trackPoint.node2 = trackEdge.node2;
			trackPoint.edge = trackEdge;
			if(updatePosition) {
				double t = Math.clamp(trackSegment.projectT(trackAxleFrame.position), 0, 1);
				if(trackSegment instanceof CurvedTrackSegment curve) {
					BezierConnection connection = curve.curve();
					// reverse edge measures its length along the secondary
					double graphLength = trackEdge.getLength();
					double quadratureLength = ((BezierConnectionExtension)connection).simurail$quadratureLength();
					double quadraturePos = SimurailMath.length(connection, 0, curve.curveT(t));
					if(curve.reversed()) {
						quadraturePos = quadratureLength - quadraturePos;
					}
					trackPoint.position = graphLength / quadratureLength * quadraturePos;
				}
				else {
					trackPoint.position = trackSegment.length() * t;
				}
			}
			else {
				trackPoint.position = 0;
			}
		}
	}

	protected void updateJoint(ServerSubLevel subLevel) {
		if(!bogey.options.enabled || trackSegment == null) {
			removeJoint();
			return;
		}

		trackSubLevelPose.orientation().conjugate(trackJointRot).mul(globalTrackRot);

		SimurailPhysicsConfig config = SimurailConfig.server().physics;
		SubLevelPhysicsSystem physics = SubLevelPhysicsSystem.require(subLevel.getLevel());
		if(offsetTimer > 0) {
			removeJoint();
		}
		boolean disableRotation = !bogey.options.allowYawOffset && !bogey.options.allowPitchOffset;
		if(trackJoint == null || !trackJoint.isValid()) {
			trackJoint = null;
			double linearDamping = config.axlePassiveLinearDamping.get();
			double angularDamping = config.axlePassiveAngularDamping.get();
			GenericConstraintConfiguration jointConfig = SimurailJoints.railJoint(
					trackFrame.position, bogey.pivot.position(axleFrame.position),
					trackJointRot, SimurailMath.ROT_I);
			trackJoint = physics.getPipeline().addConstraint(trackSubLevel, bogey.pivot.physicsBody(), jointConfig);
			trackJoint.setContactsEnabled(false);
			trackJoint.setMotor(ConstraintJointAxis.LINEAR_Y, 0, 0, linearDamping, false, 0);
			trackJoint.setMotor(ConstraintJointAxis.LINEAR_Z, 0, 0, linearDamping, false, 0);
			trackJoint.setMotor(ConstraintJointAxis.ANGULAR_Y, 0, 0, angularDamping, false, 0);
			trackJoint.setMotor(ConstraintJointAxis.ANGULAR_Z, 0, 0, angularDamping, false, 0);
			trackJoint.setLimit(ConstraintJointAxis.ANGULAR_Y, -ANGULAR_Y_LIMIT, ANGULAR_Y_LIMIT);
			trackJoint.setLimit(ConstraintJointAxis.ANGULAR_Z, -ANGULAR_Z_LIMIT, ANGULAR_Z_LIMIT);
		}
		else {
			trackJoint.setFrame1(trackFrame.position, trackJointRot);
			trackJoint.setContactsEnabled(false);
		}
		if(bogeyJoint == null || !bogeyJoint.isValid()) {
			bogeyJoint = null;
			Vector3dc bogeyJointPos = disableRotation ? staticAxleBogeyPos : bogeyAxleFrame.position;
			Quaterniondc bogeyJointRot = disableRotation ? bogey.getJointOrientation() : bogeyAxleFrame.orientation(bogeyTrackJointRot);
			GenericConstraintConfiguration jointConfig = SimurailJoints.freeJoint(
					trackFrame.position, bogeyJointPos,
					trackJointRot, bogeyJointRot);
			bogeyJoint = physics.getPipeline().addConstraint(trackSubLevel, subLevel, jointConfig);
		}
		else {
			Vector3dc jointPos = disableRotation ? staticAxleBogeyPos : bogeyAxleFrame.position;
			Quaterniondc jointRot = disableRotation ? bogey.getJointOrientation() : bogeyAxleFrame.orientation(bogeyTrackJointRot);
			bogeyJoint.setFrame1(trackFrame.position, trackJointRot);
			bogeyJoint.setFrame2(jointPos, jointRot);
		}
	}

	protected void updateLimits(ServerSubLevel subLevel, double timeStep) {
		if(trackSegment != null) {
			kLateralSigned = globalTrackCurvature.dot(globalAxleFrame.lateral);
			kLateral = Math.abs(kLateralSigned);
			kVertical = globalTrackCurvature.dot(globalAxleFrame.vertical);
		}
		else {
			kLateralSigned = 0;
			kLateral = 0;
			kVertical = 0;
		}

		if(!bogey.options.enabled || trackSegment == null) {
			removeJoint();
			return;
		}

		TrackTypeEntry trackType = TrackTypeEntries.getEntry(trackSegment.material());

		Vector3dc scale = subLevel.logicalPose().scale();
		double yLimit = 0;
		double zLimit = 0;

		if(!yFixed) {
			double yTime = bogey.options.allowVerticalMovement ? 20 : 10;
			double yDist = Math.abs(SimurailMath.projectTLinePoint(trackFrame.position, trackFrame.vertical, trackAxleFrame.position));
			yLimit = Math.max(Math.min(yDist - 0.5 * timeStep, yDist - yDist * yFixedTimer / yTime), 0);
			yFixedTimer += timeStep;
			yFixed = yLimit < 0.5 * timeStep || yFixedTimer > yTime;
			yLimit *= scale.y();
		}

		if(!zFixed) {
			double zDist = Math.abs(SimurailMath.projectTLinePoint(trackFrame.position, trackFrame.lateral, trackAxleFrame.position));
			zLimit = Math.max(Math.min(zDist - 0.5 * timeStep, zDist - zDist * zFixedTimer * 0.1), 0);
			zFixedTimer += timeStep;
			zFixed = zLimit < 0.5 * timeStep || zFixedTimer > 10;
			zLimit *= scale.z();
		}

		double t = trackSegment.projectT(trackAxleFrame.position);
		trackSubLevelPose.transformNormal(trackSegment.curvature(t, globalTrackCurvature));
		double speedSq = Mth.square(speed);
		boolean checkVertical = bogey.isInverted() || !bogey.options.allowVerticalMovement;

		if(kLateral > SimurailMath.EPSILON) {
			double lateralMaxSpeedFactor = trackType.lateralMaxSpeedFactor().getAsDouble();
			double maxSpeedSq = lateralMaxSpeedFactor / kLateral;
			if(speedSq > maxSpeedSq) {
				zLimit = Short.MAX_VALUE;
			}
		}

		if(checkVertical) {
			if(Math.abs(kVertical) > SimurailMath.EPSILON && (bogey.isInverted() ? kVertical > 0 : kVertical < 0)) {
				double verticalMaxSpeedFactor = trackType.verticalMaxSpeedFactor().getAsDouble();
				double maxSpeedSq = verticalMaxSpeedFactor / Math.abs(kVertical);
				if(speedSq > maxSpeedSq) {
					yLimit = Short.MAX_VALUE;
				}
			}
		}

		boolean disableRotation = !bogey.options.allowYawOffset && !bogey.options.allowPitchOffset;
		double bogeyVerticalPlay = disableRotation ? 0 : 0.0625 * scale.y();
		double bogeyLateralPlay = disableRotation ? 0 : 0.125 * scale.z();

		if(checkVertical) {
			trackJoint.setLimit(ConstraintJointAxis.LINEAR_Y, -yLimit, yLimit);
			bogeyJoint.setLimit(ConstraintJointAxis.LINEAR_Y, -(yLimit + bogeyVerticalPlay), yLimit + bogeyVerticalPlay);
		}
		else {
			trackJoint.setLimit(ConstraintJointAxis.LINEAR_Y, -yLimit, Short.MAX_VALUE);
			bogeyJoint.setLimit(ConstraintJointAxis.LINEAR_Y, -(yLimit + bogeyVerticalPlay), Short.MAX_VALUE);
		}

		trackJoint.setLimit(ConstraintJointAxis.LINEAR_Z, -zLimit, zLimit);
		bogeyJoint.setLimit(ConstraintJointAxis.LINEAR_Z, -(zLimit + bogeyLateralPlay), zLimit + bogeyLateralPlay);
	}

	protected void updateForces(ServerSubLevel subLevel, double timeStep) {
		if(!bogey.options.enabled) {
			removeJoint();
			resetSlip();
			return;
		}
		if(trackSegment != null) {
			removeAxleBox(subLevel);
			updateTrackForces(subLevel, timeStep);
		}
		else {
			resetSlip();
			updateWorldForces(subLevel, timeStep);
		}
	}

	protected void updateTrackForces(ServerSubLevel subLevel, double timeStep) {
		if(!bogey.options.enabled || trackSegment == null) {
			removeJoint();
			return;
		}

		SimurailPhysicsConfig config = SimurailConfig.server().physics;
		MassData massData = subLevel.getMassTracker();

		{
			double normalMass = 1 / massData.getInverseNormalMass(bogeyForceFrame.position, bogeyForceFrame.vertical);
			double friction = getTrackFriction(trackSegment);

			double brakeStrengthFactor = config.axleBrakeStrengthFactor.get();
			double brakeStrength = bogey.getGroupBrakeStrength();

			double targetSpeedFactor = config.axleTargetSpeedFactor.get();
			targetSpeed = (bogey.isUnpowered() ? 0 : bogey.getSpeed()) * targetSpeedFactor * bogey.getFacing().getAxisDirection().getStep() * bogey.getStressSign();
			double targetSign = Math.signum(targetSpeed);
			double diffSpeed = targetSpeed - speed;
			double diffSign = Math.signum(diffSpeed);
			double driveForce = 0;

			if(targetSign == diffSign) {
				double stress = bogey.calculateStressApplied();
				double driveForceMultiplier = config.axleDriveForceFactor.get();
				double driveMag = Math.min(Math.abs(diffSpeed), Math.abs(targetSpeed)) * stress * driveForceMultiplier;
				driveForce = diffSign * driveMag * (1 - brakeStrength) * Math.clamp(friction, 0.05, 1);
			}

			if(!config.axleSlipEnabled.get() || bogey.staffRestrained) {
				resetSlip();
			}
			else {
				TrackTypeEntry trackType = TrackTypeEntries.getEntry(trackSegment.material());
				double adhesionFactor = trackType.adhesionFactor().getAsDouble();
				double slipAuthority = getSlipAuthority(config);
				double overload = 0;
				if(adhesionFactor > 0 && slipAuthority > 0) {
					double maxTraction = adhesionFactor * normalMass * Math.clamp(friction, 0.05, 1);
					if(maxTraction > SimurailMath.EPSILON && Math.abs(driveForce) > maxTraction) {
						overload = (Math.abs(driveForce) / maxTraction - 1) * slipAuthority;
						// wheels only give up as much of the drive as they have authority to at this speed,
						// so a train already rolling keeps every bit of what it is putting down
						driveForce = Mth.lerp(slipAuthority, driveForce, Math.copySign(maxTraction, driveForce));
					}
				}
				updateSlipSpeed(config, overload, targetSign, friction, timeStep);
			}

			double speedSign = Math.signum(speed);
			double speedSignMag = Math.clamp(Math.abs(speed) * 1.75, 0, 1);
			double signFactor = (speedSignMag * speedSignMag * speedSignMag * 0.25 + speedSignMag * 0.75) * speedSign;
			double brakeForce = signFactor * (brakeStrengthFactor * brakeStrength) * normalMass * Math.max(friction, 0.05);

			bogeyForceFrame.direction.mul(driveForce * timeStep, queuedTractionForce);
			bogeyForceFrame.direction.mul(-brakeForce * timeStep, queuedBrakeForce);

			if(friction < 1) {
				visualSpeed = Mth.lerp(friction * 0.9 + 0.1, targetSpeed, speed) + slipSpeed;
			}
			else {
				visualSpeed = speed + slipSpeed;
			}
		}

		QueuedForceGroup tractionGroup = subLevel.getOrCreateQueuedForceGroup(SimurailForceGroups.TRACTION.get());
		tractionGroup.applyAndRecordPointForce(bogeyForceFrame.position, queuedTractionForce);
		QueuedForceGroup brakeGroup = subLevel.getOrCreateQueuedForceGroup(SimurailForceGroups.BRAKE.get());
		brakeGroup.applyAndRecordPointForce(bogeyForceFrame.position, queuedBrakeForce);

		if(trackSubLevel != null) {
			queuedReactionForce.set(queuedTractionForce).add(queuedBrakeForce);
			subLevel.logicalPose().transformNormal(queuedReactionForce);
			trackSubLevelPose.transformNormalInverse(queuedReactionForce);
			queuedReactionForce.negate();
			RigidBodyHandle.of(trackSubLevel).applyImpulseAtPoint(trackFrame.position, queuedReactionForce);
		}
	}

	protected double getTrackFriction(TrackSegment trackSegment) {
		return 1;
	}

	protected double getSlipAuthority(SimurailPhysicsConfig config) {
		double maxSpeed = config.axleSlipMaxSpeed.get();
		if(maxSpeed <= SimurailMath.EPSILON) {
			return 0;
		}
		double fadeFrom = maxSpeed * (1 - SLIP_FADE_BAND);
		return 1 - Math.clamp((Math.abs(speed) - fadeFrom) / (maxSpeed - fadeFrom), 0, 1);
	}

	protected void updateSlipSpeed(SimurailPhysicsConfig config, double overload, double driveSign, double friction, double timeStep) {
		double decay = config.axleSlipDecay.get() * Math.clamp(friction, 0.05, 1) * timeStep;
		double maxSlipSpeed = Math.abs(targetSpeed - speed);
		double load = Math.min(overload, MAX_SLIP_OVERLOAD);

		if(overload > 0 && slipBurst <= 0 && Math.abs(slipSpeed) < SLIP_GRIP_SPEED) {
			slipBind += load * timeStep;
			if(slipBind < config.axleSlipBindTime.get()) {
				// Bound: the wheels are held to the rail, so nothing is slipping and nothing sparks yet
				slipSpeed -= Math.copySign(Math.min(Math.abs(slipSpeed), decay), slipSpeed);
				return;
			}
			// Breaking loose: the wind up starts going into the wheels, past their driven speed
			slipBurst = maxSlipSpeed * config.axleSlipBurstFactor.get();
			slipBind = 0;
		}

		double slipLimit = maxSlipSpeed + slipBurst;

		if(slipBurst > 0 && Math.abs(slipSpeed) < slipLimit) {
			// Still unloading
			slipSpeed += driveSign * slipLimit * (timeStep / SLIP_RELEASE_TIME);
		}
		else if(overload > 0) {
			slipSpeed += driveSign * load * config.axleSlipAcceleration.get() * timeStep;
		}
		else {
			slipBind -= Math.min(slipBind, timeStep);
		}
		slipBurst -= Math.min(slipBurst, decay);
		slipSpeed -= Math.copySign(Math.min(Math.abs(slipSpeed), decay), slipSpeed);
		slipSpeed = Math.clamp(slipSpeed, -slipLimit, slipLimit);
	}

	protected void updateWorldForces(ServerSubLevel subLevel, double timeStep) {
		if(!bogey.options.enabled || trackSegment != null || !bogey.options.type.groundDrivable()) {
			return;
		}
		// TODO check if we want to move wheels out of ground
		//createAxleBox(subLevel);

		ServerLevel level = subLevel.getLevel();

		SimurailPhysicsConfig config = SimurailConfig.server().physics;
		double targetSpeedFactor = config.axleTargetSpeedFactor.get();
		targetSpeed = (bogey.isUnpowered() ? 0 : bogey.getSpeed()) * targetSpeedFactor * bogey.getFacing().getAxisDirection().getStep() * bogey.getStressSign();

		if(clipResult.getType() != HitResult.Type.BLOCK) {
			if(targetSpeed != 0) {
				visualSpeed = targetSpeed;
			}
			return;
		}

		Pose3dc clipSubLevelPose = clipSubLevel == null ? SimurailMath.POSE_I : clipSubLevel.logicalPose();
		MassData massData = subLevel.getMassTracker();

		{
			double normalMass = 1 / massData.getInverseNormalMass(bogeyForceFrame.position, bogeyForceFrame.vertical);
			double frictionFactor = config.axleDerailFrictionFactor.get();
			double friction = PhysicsBlockPropertyHelper.getFriction(level.getBlockState(clipResult.getBlockPos())) * frictionFactor;

			double brakeStrengthFactor = config.axleBrakeStrengthFactor.get();
			double brakeStrength = bogey.getGroupBrakeStrength();

			double targetSign = Math.signum(targetSpeed);
			double diffSpeed = targetSpeed - speed;
			double diffSign = Math.signum(diffSpeed);
			double driveForce = 0;

			if(targetSign == diffSign) {
				double stress = bogey.calculateStressApplied();
				double driveForceMultiplier = config.axleDriveForceFactor.get();
				double driveMag = Math.min(Math.abs(diffSpeed), Math.abs(targetSpeed)) * stress * driveForceMultiplier;
				driveForce = diffSign * driveMag * (1 - brakeStrength) * Math.clamp(friction, 0.05, 1);
			}

			double speedSign = Math.signum(speed);
			double speedSignMag = Math.clamp(Math.abs(speed) * 1.75, 0, 1);
			double signFactor = (speedSignMag * speedSignMag * speedSignMag * 0.25 + speedSignMag * 0.75) * speedSign;
			double brakeForce = signFactor * (brakeStrengthFactor * brakeStrength) * normalMass * Math.max(friction, 0.05);

			bogeyForceFrame.direction.mul(driveForce * timeStep, queuedTractionForce);
			bogeyForceFrame.direction.mul(-brakeForce * timeStep, queuedBrakeForce);

			if(friction < 1) {
				visualSpeed = Mth.lerp(friction * 0.9 + 0.1, targetSpeed, speed);
			}
			else {
				visualSpeed = speed;
			}
		}

		QueuedForceGroup tractionGroup = subLevel.getOrCreateQueuedForceGroup(SimurailForceGroups.TRACTION.get());
		tractionGroup.applyAndRecordPointForce(bogeyForceFrame.position, queuedTractionForce);
		QueuedForceGroup brakeGroup = subLevel.getOrCreateQueuedForceGroup(SimurailForceGroups.BRAKE.get());
		brakeGroup.applyAndRecordPointForce(bogeyForceFrame.position, queuedBrakeForce);

		if(clipSubLevel != null) {
			queuedReactionForce.set(queuedTractionForce).add(queuedBrakeForce);
			subLevel.logicalPose().transformNormal(queuedReactionForce);
			clipSubLevelPose.transformNormalInverse(queuedReactionForce);
			queuedReactionForce.negate();
			RigidBodyHandle.of(clipSubLevel).applyImpulseAtPoint(clipPos, queuedReactionForce);
		}
	}

	protected void findTrack(ServerSubLevel subLevel) {
		Pose3dc pivotPose = bogey.pivotPose;
		axleFrame.transform(pivotPose, globalAxleFrame);
		trackSegment = TrackSegmentHelper.findTrackSegment(subLevel.getLevel(), subLevel, globalAxleFrame.position, globalAxleFrame.direction, globalAxleFrame.vertical, bogey.isInverted(), bogey.options.type.trackTypes());
		if(trackSegment != null) {
			trackRecheckTime = SimurailConfig.server().physics.axleTrackRecheckTime.get();
		}
		else {
			trackRecheckTime = SimurailConfig.server().physics.axleTrackCheckTime.get();
		}
		bogey.setChanged();
	}

	protected BlockHitResult findGround(ServerSubLevel subLevel) {
		ServerLevel level = subLevel.getLevel();
		Vec3 clipStart = bogey.pivotPose.transformPosition(new Vec3(axleFrame.position.x, axleFrame.position.y + 0.5, axleFrame.position.z));
		Vec3 clipEnd = JOMLConversion.toMojang(globalAxleFrame.position);
		ClipContext clipContext = new ClipContext(clipStart, clipEnd, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, CollisionContext.empty());
		((ClipContextExtension)clipContext).sable$setIgnoredSubLevel(subLevel);
		return level.clip(clipContext);
	}

	protected void resetProbe(TravellingPoint point) {
		probe.node1 = point.node1;
		probe.node2 = point.node2;
		probe.edge = point.edge;
		probe.position = point.position;
	}

	protected void removeJoint() {
		if(trackJoint != null) {
			trackJoint.remove();
			trackJoint = null;
		}
		if(bogeyJoint != null) {
			bogeyJoint.remove();
			bogeyJoint = null;
		}
	}

	protected void createAxleBox(ServerSubLevel subLevel) {
		SubLevelPhysicsSystem physics = SubLevelPhysicsSystem.require(subLevel.getLevel());
		Quaterniond rot = SimurailMath.rot(new Vector3d(1, 1, 0), new Vector3d(-1, 1, 0), new Quaterniond());
		if(axleBox == null || axleBox.isRemoved()) {
			Pose3d axleBoxPose = new Pose3d();
			axleBoxPose.position().set(globalAxleFrame.position);
			axleBoxPose.orientation().set(bogey.pivotPose.orientation()).mul(rot);
			axleBox = new AttachableBoxPhysicsObject(subLevel, axleBoxPose, new Vector3d(Math.sqrt(0.5) * 0.0625, Math.sqrt(0.5) * 0.0625, 0.5), 0);
			physics.addObject(axleBox);
		}
		if(axleBoxJoint == null || !axleBoxJoint.isValid()) {
			FixedConstraintConfiguration jointConfig = new FixedConstraintConfiguration(bogey.pivot.position(axleFrame.position), new Vector3d(0, -0.3125, 0), rot);
			axleBoxJoint = physics.getPipeline().addConstraint(bogey.pivot.physicsBody(), axleBox, jointConfig);
			axleBoxJoint.setContactsEnabled(false);
		}
	}

	protected void removeAxleBox(ServerSubLevel subLevel) {
		if(axleBoxJoint != null) {
			axleBoxJoint.remove();
			axleBoxJoint = null;
		}
		if(axleBox != null) {
			SubLevelPhysicsSystem physics = SubLevelPhysicsSystem.require(subLevel.getLevel());
			physics.removeObject(axleBox);
			axleBox = null;
		}
	}

	protected void invalidate(ServerSubLevel subLevel) {
		trackSegment = null;
		trackGraph = null;
		removeJoint();
		removeAxleBox(subLevel);
	}

	protected ITrackSelector control(TravellingPoint point) {
		return (graph, pair) -> {
			PhysicsBogeyAxle followingAxle = null;
			TravellingPoint nextPoint = null;
			if(isCurrentFront()) {
				PhysicsBogeyBlockEntity nextBogey = bogey.getConnected(logicalFront);
				if(nextBogey != null) {
					followingAxle = nextBogey.getAxle(!bogey.getConnectedToFront(logicalFront));
				}
			}
			else {
				followingAxle = other();
			}
			if(followingAxle != null && followingAxle.trackGraph == graph) {
				nextPoint = followingAxle.trackPoint;
			}
			if(nextPoint == null || nextPoint.edge == null) {
				if(!currentPath.isEmpty()) {
					return navigate(point, currentPath).apply(graph, pair);
				}
				else {
					return steer(point).apply(graph, pair);
				}
			}
			else {
				MutableBoolean flag = new MutableBoolean(false);
				Map.Entry<TrackNode, TrackEdge> result = follow(nextPoint, flag::setValue).apply(graph, pair);
				if(flag.booleanValue()) {
					return result;
				}
				else {
					return steer(point).apply(graph, pair);
				}
			}
		};
	}

	protected ITrackSelector followOtherOrSteer(TravellingPoint point) {
		return (graph, pair) -> {
			PhysicsBogeyAxle followingAxle = other();
			TravellingPoint nextPoint = null;
			if(followingAxle != null && followingAxle.trackGraph == graph) {
				nextPoint = followingAxle.trackPoint;
			}
			if(nextPoint == null || nextPoint.edge == null) {
				return steer(point).apply(graph, pair);
			}
			else {
				MutableBoolean flag = new MutableBoolean(false);
				Map.Entry<TrackNode, TrackEdge> result = follow(nextPoint, flag::setValue).apply(graph, pair);
				if(flag.booleanValue()) {
					return result;
				}
				else {
					return steer(point).apply(graph, pair);
				}
			}
		};
	}

	protected ITrackSelector navigate(TravellingPoint point, List<Couple<TrackNode>> path) {
		return (graph, pair) -> {
			List<Map.Entry<TrackNode, TrackEdge>> validTargets = pair.getSecond();
			if(path.isEmpty()) {
				return steer(point).apply(graph, pair);
			}
			for(Couple<TrackNode> targetEdge : path) {
				for(Map.Entry<TrackNode, TrackEdge> entry : validTargets) {
					TrackEdge candEdge = entry.getValue();
					if(candEdge.node1 != targetEdge.getFirst() && candEdge.node2 != targetEdge.getSecond()) {
						continue;
					}
					return entry;
				}
			}
			return steer(point).apply(graph, pair);
		};
	}

	protected ITrackSelector steer(TravellingPoint point) {
		return (graph, pair) -> {
			List<Map.Entry<TrackNode, TrackEdge>> targets = pair.getSecond();
			List<Map.Entry<TrackNode, TrackEdge>> leftTargets = new ArrayList<>();
			List<Map.Entry<TrackNode, TrackEdge>> rightTargets = new ArrayList<>();
			Map.Entry<TrackNode, TrackEdge> straightTarget = null;
			Object2DoubleMap<TrackNode> turnValues = new Object2DoubleArrayMap<>(targets.size());

			Vector3dc trackLat = trackAxleFrame.lateral;
			Vector3d turnCurvature = new Vector3d();
			double minTurn = Double.MAX_VALUE;
			double maxTurn = -Double.MAX_VALUE;

			for(Map.Entry<TrackNode, TrackEdge> entry : targets) {
				double turn = 0;
				TrackEdge edge = entry.getValue();
				if(edge.isTurn()) {
					turn = SimurailMath.cachedControlPoints(edge.getTurn()).curvature(0, turnCurvature).dot(trackLat);
					(turn < 0 ? leftTargets : rightTargets).add(entry);
				}
				else {
					straightTarget = entry;
				}
				turnValues.put(entry.getKey(), turn);
				minTurn = Math.min(minTurn, turn);
				maxTurn = Math.max(maxTurn, turn);
			}

			double steerValue = bogey.getGroupSteerValue();
			Map.Entry<TrackNode, TrackEdge> bestTarget = null;

			if(straightTarget != null && (steerValue == 0 ||
					steerValue < 0 && leftTargets.isEmpty() ||
					steerValue > 0 && rightTargets.isEmpty())) {
				bestTarget = straightTarget;
			}
			else if(!leftTargets.isEmpty() && (steerValue <= 0 || rightTargets.isEmpty())) {
				double targetTurn = Mth.lerp(steerValue, Math.max(minTurn, 0), maxTurn);
				double bestTurn = Double.MAX_VALUE;
				for(Map.Entry<TrackNode, TrackEdge> entry : leftTargets) {
					double diff = Math.abs(targetTurn - turnValues.getDouble(entry.getKey()));
					if(diff < bestTurn) {
						bestTurn = diff;
						bestTarget = entry;
					}
				}
			}
			else {
				double targetTurn = Mth.lerp(steerValue, Math.max(minTurn, 0), maxTurn);
				double bestTurn = Double.MAX_VALUE;
				for(Map.Entry<TrackNode, TrackEdge> entry : rightTargets) {
					double diff = Math.abs(targetTurn - turnValues.getDouble(entry.getKey()));
					if(diff < bestTurn) {
						bestTurn = diff;
						bestTarget = entry;
					}
				}
			}

			return bestTarget;
		};
	}

	protected ITrackSelector follow(TravellingPoint other, BooleanConsumer success) {
		return (graph, pair) -> {
			List<Map.Entry<TrackNode, TrackEdge>> validTargets = pair.getSecond();
			for(Map.Entry<TrackNode, TrackEdge> entry : validTargets) {
				if(entry.getKey() == other.node1 || entry.getKey() == other.node2) {
					if(success != null) {
						success.accept(true);
					}
					return entry;
				}
			}

			List<List<Map.Entry<TrackNode, TrackEdge>>> frontiers = new ArrayList<>(validTargets.size());
			List<Set<TrackEdge>> visiteds = new ArrayList<>(validTargets.size());

			for(Map.Entry<TrackNode, TrackEdge> validTarget : validTargets) {
				List<Map.Entry<TrackNode, TrackEdge>> e = new ArrayList<>();
				e.add(validTarget);
				frontiers.add(e);
				Set<TrackEdge> e2 = new HashSet<>();
				e2.add(validTarget.getValue());
				visiteds.add(e2);
			}

			for(int i = 0; i < 20; i++) {
				for(int j = 0; j < validTargets.size(); j++) {
					Map.Entry<TrackNode, TrackEdge> entry = validTargets.get(j);
					List<Map.Entry<TrackNode, TrackEdge>> frontier = frontiers.get(j);
					if(frontier.isEmpty()) {
						continue;
					}
					Map.Entry<TrackNode, TrackEdge> currentEntry = frontier.remove(0);
					for(Map.Entry<TrackNode, TrackEdge> nextEntry : graph.getConnectionsFrom(currentEntry.getKey()).entrySet()) {
						TrackEdge nextEdge = nextEntry.getValue();
						if(!visiteds.get(j).add(nextEdge)) {
							continue;
						}
						if(!currentEntry.getValue().canTravelTo(nextEdge)) {
							continue;
						}
						TrackNode nextNode = nextEntry.getKey();
						if(nextNode == other.node1 || nextNode == other.node2) {
							if(success != null) {
								success.accept(true);
							}
							return entry;
						}
						frontier.add(nextEntry);
					}
				}
			}

			if(success != null) {
				success.accept(false);
			}

			return validTargets.get(0);
		};
	}

	public boolean isCurrentFront() {
		return logicalFront && speed > 0 || !logicalFront && speed < 0;
	}

	public Frame3dc getTrackFrame() {
		return trackFrame;
	}

	public double getLateralCurvature() {
		return kLateral;
	}

	public double getVerticalCurvature() {
		return kVertical;
	}

	public TrackGraph getTrackGraph() {
		return trackGraph;
	}

	public TravellingPoint getTrackPoint() {
		return trackPoint;
	}

	public PhysicsBogeyProbeData getProbeData() {
		return probeData;
	}

	public PhysicsBogeyAxle other() {
		return this == bogey.axleFront ? bogey.axleBack : bogey.axleFront;
	}

	public boolean hasTrack() {
		return trackSegment != null;
	}

	public void setCurrentPath(List<Couple<TrackNode>> path) {
		currentPath = path;
	}

	protected CompoundTag write() {
		CompoundTag tag = new CompoundTag();
		if(trackSegment != null) {
			tag.put("segment", trackSegment.write());
		}
		tag.putBoolean("y_fixed", yFixed);
		tag.putBoolean("z_fixed", zFixed);
		return tag;
	}

	protected void read(CompoundTag tag) {
		if(tag.contains("segment")) {
			trackSegment = TrackSegment.read(tag.getCompound("segment"));
		}
		yFixed = tag.getBoolean("y_fixed");
		zFixed = tag.getBoolean("z_fixed");
	}

	// Mutable physics fields
	protected final Frame3d globalAxleFrame = new Frame3d();
	protected final Frame3d bogeyAxleFrame = new Frame3d();
	protected final Frame3d trackAxleFrame = new Frame3d();

	protected final Frame3d trackFrame = new Frame3d();
	protected final Frame3d bogeyForceFrame = new Frame3d();
	protected final Quaterniond globalTrackRot = new Quaterniond();

	protected final Vector3d clipPos = new Vector3d();

	protected final Quaterniond trackJointRot = new Quaterniond();
	protected final Quaterniond bogeyTrackJointRot = new Quaterniond();

	protected final Vector3d globalTrackCurvature = new Vector3d();

	protected final Vector3d queuedBrakeForce = new Vector3d();
	protected final Vector3d queuedTractionForce = new Vector3d();
	protected final Vector3d queuedReactionForce = new Vector3d();

	protected final Vector3d globalAxleVel = new Vector3d();
	protected final Vector3d globalTrackVel = new Vector3d();
	protected final Vector3d globalHitVel = new Vector3d();
	protected final Vector3d globalRelVel = new Vector3d();
	protected final Vector3d bogeyRelVel = new Vector3d();
}
