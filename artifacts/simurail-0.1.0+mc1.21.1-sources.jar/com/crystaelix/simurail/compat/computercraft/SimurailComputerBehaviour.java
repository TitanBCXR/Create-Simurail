package com.crystaelix.simurail.compat.computercraft;

import java.util.function.Supplier;

import com.crystaelix.simurail.compat.computercraft.peripheral.PhysicsBogeyPeripheral;
import com.crystaelix.simurail.compat.computercraft.peripheral.ProbeReaderPeripheral;
import com.crystaelix.simurail.compat.computercraft.peripheral.RemoteControllerPeripheral;
import com.crystaelix.simurail.compat.computercraft.peripheral.TrackSwitchPeripheral;
import com.crystaelix.simurail.content.bogey.PhysicsBogeyBlockEntity;
import com.crystaelix.simurail.content.probe_reader.ProbeReaderBlockEntity;
import com.crystaelix.simurail.content.remote_controller.RemoteControllerBlockEntity;
import com.crystaelix.simurail.content.track_switch.TrackSwitchBlockEntity;
import com.simibubi.create.compat.computercraft.AbstractComputerBehaviour;
import com.simibubi.create.compat.computercraft.events.ComputerEvent;
import com.simibubi.create.compat.computercraft.implementation.peripherals.SyncedPeripheral;
import com.simibubi.create.foundation.blockEntity.SmartBlockEntity;

import dan200.computercraft.api.peripheral.IPeripheral;
import net.minecraft.core.registries.BuiltInRegistries;

public class SimurailComputerBehaviour extends AbstractComputerBehaviour {

	SyncedPeripheral<?> peripheral;
	Supplier<SyncedPeripheral<?>> peripheralSupplier;
	SmartBlockEntity be;

	public SimurailComputerBehaviour(SmartBlockEntity be) {
		super(be);
		this.peripheralSupplier = getPeripheralFor(be);
		this.be = be;
	}

	public static Supplier<SyncedPeripheral<?>> getPeripheralFor(SmartBlockEntity be) {
		return switch(be) {
		case PhysicsBogeyBlockEntity pbbe -> () -> new PhysicsBogeyPeripheral(pbbe);
		case ProbeReaderBlockEntity prbe -> () -> new ProbeReaderPeripheral(prbe);
		case RemoteControllerBlockEntity rcbe -> () -> new RemoteControllerPeripheral(rcbe);
		case TrackSwitchBlockEntity tsbe -> () -> new TrackSwitchPeripheral(tsbe);
		case null, default -> throw new IllegalArgumentException("No peripheral available for " + BuiltInRegistries.BLOCK_ENTITY_TYPE.getKey(be.getType()));
		};
	}

	@Override
	public IPeripheral getPeripheralCapability() {
		if(peripheral == null) {
			peripheral = peripheralSupplier.get();
		}
		return peripheral;
	}

	@Override
	public void removePeripheral() {
		if(peripheral != null) {
			getWorld().invalidateCapabilities(be.getBlockPos());
		}
	}

	@Override
	public void prepareComputerEvent(ComputerEvent event) {
		if(peripheral != null) {
			peripheral.prepareComputerEvent(event);
		}
	}
}
