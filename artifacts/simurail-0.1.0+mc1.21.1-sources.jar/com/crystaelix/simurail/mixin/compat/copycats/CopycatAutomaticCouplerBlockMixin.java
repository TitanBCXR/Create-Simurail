package com.crystaelix.simurail.mixin.compat.copycats;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

import com.copycatsplus.copycats.foundation.copycat.CopycatExternalContext;
import com.copycatsplus.copycats.foundation.copycat.ICopycatBlock;
import com.crystaelix.simurail.content.automatic_coupler.copycat.CopycatAutomaticCouplerBlock;
import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.simibubi.create.content.decoration.copycat.CopycatBlockEntity;
import com.simibubi.create.content.decoration.copycat.WaterloggedCopycatBlock;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.BlockAndTintGetter;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

// Use Copycats+ logic instead when it is present
@Mixin(CopycatAutomaticCouplerBlock.class)
public abstract class CopycatAutomaticCouplerBlockMixin extends WaterloggedCopycatBlock implements ICopycatBlock {

	public CopycatAutomaticCouplerBlockMixin(Properties properties) {
		super(properties);
	}

	@Override
	public BlockState getAppearance(BlockState state, BlockAndTintGetter level, BlockPos pos, Direction side, BlockState queryState, BlockPos queryPos) {
		if(!isCTEnabled(state, level, queryPos)) {
			return state;
		}
		return super.getAppearance(state, level, pos, side, queryState, queryPos);
	}

	@Override
	public InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hitResult) {
		return toggleCT(state, level, pos, player, hitResult);
	}

	@Unique(silent = true)
	@Override
	public ItemInteractionResult useItemOn(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hitResult) {
		return super.useItemOn(stack, state, level, pos, player, hand, hitResult);
	}

	@WrapMethod(method = "isIgnoredConnectivitySide")
	private boolean simurail$copycats$isIgnoredConnectivitySide(BlockAndTintGetter level, BlockState state, Direction face, BlockPos fromPos, BlockPos toPos, Operation<Boolean> original) {
		boolean originalValue = original.call(level, state, face, fromPos, toPos);
		if(!originalValue) {
			return false;
		}
		if(CopycatExternalContext.isForBlockingLogic()) {
			return false;
		}
		if(toPos == null) {
			return true;
		}
		return !checkConnection(level, toPos, fromPos, level.getBlockState(toPos));
	}

	@WrapMethod(method = "canConnectTexturesToward")
	private boolean simurail$copycats$canConnectTexturesToward(BlockAndTintGetter level, BlockPos fromPos, BlockPos toPos, BlockState fromState, Operation<Boolean> original) {
		boolean originalValue = original.call(level, fromPos, toPos, fromState);
		if(originalValue) {
			return true;
		}
		BlockState toState = level.getBlockState(toPos);
		if(!toState.is(this) && toState.getBlock() instanceof ICopycatBlock) {
			return true;
		}
		return checkConnection(level, fromPos, toPos, fromState);
	}

	@WrapMethod(method = "hidesNeighborFace")
	private boolean simurail$copycats$hidesNeighborFace(BlockGetter level, BlockPos pos, BlockState state, BlockState neighborState, Direction dir, Operation<Boolean> original) {
		return ICopycatBlock.hidesNeighborFace(level, pos, state, neighborState, dir);
	}

	@Unique(silent = true)
	@Override
	public BlockState mirror(BlockState state, Mirror mirror) {
		return super.mirror(state, mirror);
	}

	@Unique(silent = true)
	@Override
	public BlockState rotate(BlockState state, Rotation rot) {
		return super.rotate(state, rot);
	}
}
